/**
 * 
 */
package de.hrw.wi.persistence.dto;

import de.hrw.wi.types.Datum;

/**
 * DataTransferObject (DTO) für Buchungen
 * 
 * @author andriesc
 *
 */
public class BookingDTO {
	private int state;
	private String carId;
	private String customerId;
	private Datum from;
	private Datum to;
	
	public BookingDTO(int state, String car_id, Datum from, Datum to, String customer_id) {
		this.state = state;
		this.carId = car_id;
		this.customerId = customer_id;
		this.from = from;
		this.to = to;
	}

	public int getState() {
		return state;
	}

	public String getCarId() {
		return carId;
	}

	public Datum getFrom() {
		return from;
	}

	public Datum getTo() {
		return to;
	}

	public String getCustomerId() {
		return customerId;
	}

}
