package de.hrw.wi.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import de.hrw.wi.persistence.dto.BookingDTO;
import de.hrw.wi.types.Datum;

public class RealDatabase implements DatabaseReadInterface, DatabaseWriteInterface {

	private final String dbURL = "jdbc:hsqldb:file:../carrental-db-layer/database/carrental_db";
	private final String user = "sa";
	private final String password = "";

	private ResultSet executeQuery(String sql) throws SQLException {
		Connection c = null;
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			ResultSet rs = c.createStatement().executeQuery(sql);
			c.commit();
			return rs;
		} finally {
			try {
				if (c != null)
					c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private int executeUpdate(String sql) throws SQLException {
		Connection c = null;
		try {
			c = DriverManager.getConnection(dbURL, user, password);
			int result = c.createStatement().executeUpdate(sql);
			c.commit();
			return result;
		} finally {
			try {
				if (c != null)
					c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private List<String> getResultAsString(String sql) {
		List<String> list = new ArrayList<String>();
		try {
			ResultSet result = executeQuery(sql);
			while (result.next())
				list.add(result.getString(1));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	private String getString(String sql) {
		try {
			ResultSet result = executeQuery(sql);
			if (result.next())
				return result.getString(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 
	 * @param datum
	 *            Das Datum als Typ "Datum"
	 * @return Umgerechnet in String "JJJJ-MM-TT"
	 */
	private String convertDate(Datum datum) {
		return Integer.toString(datum.getJahr()) + "-" + ((datum.getMonat() < 10) ? "0" : "")
				+ Integer.toString(datum.getMonat()) + "-" + ((datum.getTagImMonat() < 10) ? "0" : "")
				+ Integer.toString(datum.getTagImMonat());
	}

	@Override
	public void addCar(String id, String brand) throws PersistenceException {
		if (!id.equals("") && !brand.equals("")) {
			try {
				int res = executeUpdate("INSERT INTO CARS VALUES(\'" + id + "\', \'" + brand + "\', " + "true" + ")");
				if (res == 0)
					throw new PersistenceException("Car could not be added.");
			} catch (SQLException e) {
				throw new PersistenceException("Car could not be added.");
			}
		} else
			throw new PersistenceException("Car could not be added.");
	}

	@Override
	public Set<String> getAllCars() {
		return new HashSet<String>(getResultAsString("SELECT id FROM CARS"));
	}

	@Override
	public String getCarBrand(String id) {
		return getString("SELECT brand FROM CARS WHERE id=\'" + id + "\'");
	}

	@Override
	public Set<BookingDTO> getBookingsForCarAsDTOs(String id) {
		Set<BookingDTO> list = new HashSet<BookingDTO>();
		try {
			ResultSet result = executeQuery(
					"SELECT start, end, state, customer_id FROM BOOKINGS WHERE car_id=\'" + id + "\'");
			while (result.next()) {
				Datum start = new Datum(result.getDate(1).toLocalDate().getYear(),
						result.getDate(1).toLocalDate().getMonthValue(),
						result.getDate(1).toLocalDate().getDayOfMonth());
				Datum end = new Datum(result.getDate(2).toLocalDate().getYear(),
						result.getDate(2).toLocalDate().getMonthValue(),
						result.getDate(2).toLocalDate().getDayOfMonth());
				BookingDTO dto = new BookingDTO(result.getInt(3), id, start, end, result.getString(4));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean isCarAvailable(String id, Datum from, Datum to) {
		// Suche vorhandene Buchungen, deren Start-Datum zwischen from und to
		// liegt
		List<String> bookings1 = getResultAsString("SELECT car_id FROM BOOKINGS where car_id=\'" + id
				+ "\' AND start>=\'" + convertDate(from) + "\' AND start<=\'" + convertDate(to) + "\' ");
		// Suche vorhandene Buchungen, deren End-Datum zwischen from und to
		// liegt
		List<String> bookings2 = getResultAsString("SELECT car_id FROM BOOKINGS where car_id=\'" + id + "\' AND end>=\'"
				+ convertDate(from) + "\' AND end<=\'" + convertDate(to) + "\' ");
		// Suche vorhandene Buchungen, deren Start-Datum vor from und deren
		// End-Datum nach to liegen
		List<String> bookings3 = getResultAsString("SELECT car_id FROM BOOKINGS where car_id=\'" + id
				+ "\' AND start<=\'" + convertDate(from) + "\' AND end>=\'" + convertDate(to) + "\' ");
		return (bookings1.size() == 0) && (bookings2.size() == 0) && (bookings3.size() == 0);
	}

	@Override
	public Set<String> findAvailableCar(Datum from, Datum to) {
		Set<String> cars = getAllCars();
		Set<String> availCars = new HashSet<String>();
		for (String id : cars) {
			if (isCarAvailable(id, from, to))
				availCars.add(id);
		}
		return availCars;
	}

	@Override
	public Set<String> getAllCustomers() {
		// TODO Aufgabe 2: Diese Methode soll die IDs aller Kunden aus der
		// Datenbank holen. Implementieren Sie die Methode so fertig, dass der
		// Testfall DatabaseReadInterfaceTest.testGetAllCustomers() fehlerfrei
		// durchläuft.
		return null;
	}

	@Override
	public String getFirstName(String id) {
		return getString("SELECT firstname FROM CUSTOMERS WHERE id=\'" + id + "\'");
	}

	@Override
	public String getLastName(String id) {
		return getString("SELECT name FROM CUSTOMERS WHERE id=\'" + id + "\'");
	}

	@Override
	public void upsertBookingForCar(String car_id, String customer_id, Datum from, Datum to, int state) {
		if (!car_id.equals("") && !customer_id.equals("")) {
			boolean foundBooking = false;

			// Prüfen, ob Buchung gefunden werden kann
			Set<BookingDTO> dtos = getBookingsForCarAsDTOs(car_id);
			for (BookingDTO dto : dtos) {
				if ((dto.getFrom().equals(from)) && (dto.getTo().equals(to))) {
					foundBooking = true;
					break;
				}
			}
			if (foundBooking) {
				// Buchung wurde gefunden, UPDATE
				try {
					int res = executeUpdate("UPDATE BOOKINGS SET state=" + state + ", customer_id=\'" + customer_id
							+ "\' WHERE car_id=\'" + car_id + "\' AND start=\'" + convertDate(from) + "\' AND end=\'"
							+ convertDate(to) + "\';");
					if (res == 0)
						throw new PersistenceException("Booking could not be updated.");
				} catch (SQLException e) {
					throw new PersistenceException("Booking could not be updated.");
				}
			} else {
				// INSERT
				try {
					int res = executeUpdate("INSERT INTO BOOKINGS VALUES(\'" + car_id + "\', \'" + customer_id
							+ "\', \'" + convertDate(from) + "\', \'" + convertDate(to) + "\', " + state + ")");
					if (res == 0)
						throw new PersistenceException("Booking could not be inserted.");
				} catch (SQLException e) {
					throw new PersistenceException("Booking could not be inserted.");
				}

			}
		} else
			throw new PersistenceException("Illegal values, booking could not be updated.");
	}
}
