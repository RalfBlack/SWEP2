/**
 * 
 */
package de.hrw.wi.types;

/**
 * Ein ganz einfacher Typ für Datumswerte. 
 * 
 * @author andriesc
 * 
 */
public class Datum {
	private int jahr;
	private int monat;
	private int tagImMonat;

	public Datum(int jahr, int monat, int tagImMonat) {
		this.jahr = jahr;
		this.monat = monat;
		this.tagImMonat = tagImMonat;
	}

	/**
	 * Zwei Datumsobjekte sollen gleich sein, wenn das darin gespeicherte Datum
	 * gleich ist
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Datum other = (Datum) obj;
		if ((other.jahr == this.jahr) && (other.monat == this.monat)
				&& (other.tagImMonat == this.tagImMonat))
			return true;
		else
			return false;
	}

	/**
	 * Zwei Datumsobjekte sollen den gleichen Hashwert haben, wenn das darin
	 * gespeicherte Datum gleich ist.
	 */
	@Override
	public int hashCode() {
		return jahr * 365 + monat * 31 + tagImMonat;
	}

	/**
	 * 
	 * @param other
	 *            ein anderes Datum, mit dem verglichen werden soll
	 * @return true, wenn das Datum vor dem Datum other liegt
	 */
	public boolean isBefore(Datum other) {
		return this.hashCode() < other.hashCode();
	}

	public int getJahr() {
		return jahr;
	}

	public int getMonat() {
		return monat;
	}

	public int getTagImMonat() {
		return tagImMonat;
	}
}
