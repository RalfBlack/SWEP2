package de.hrw.wi.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.sql.SQLException;
import java.util.Set;

import org.dbunit.IDatabaseTester;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Before;
import org.junit.Test;

import de.hrw.wi.persistence.dto.BookingDTO;
import de.hrw.wi.types.Datum;

public class DatabaseWriteInterfaceTest {
	private final String dbURL = "jdbc:hsqldb:file:../carrental-db-layer/database/carrental_db";
	private final String user = "sa";
	private final String password = "";

	DatabaseWriteInterface dbWrite;
	DatabaseReadInterface dbRead;
	private IDatabaseTester databaseTester;

	@Before
	public void setUp() throws Exception {
		databaseTester = new JdbcDatabaseTester("org.hsqldb.jdbcDriver", dbURL, user, password);
		databaseTester
				.setDataSet(new FlatXmlDataSetBuilder().build(new File("../carrental-db-layer/db_full_export.xml")));
		databaseTester.onSetup();
		RealDatabase db = new RealDatabase();
		dbWrite = db;
		dbRead = db;
	}

	@Test
	public void testAddCar() throws SQLException, Exception {
		assertEquals(5, dbRead.getAllCars().size());
		dbWrite.addCar("RV-TT 777", "Audi");
		assertEquals(6, dbRead.getAllCars().size());
		assertEquals("Audi", dbRead.getCarBrand("RV-TT 777"));
		// TODO Aufgabe 3a: Erweitern Sie den Test: Überprüfen Sie hier mit
		// DBUnit, ob die Datenbank nach dem Aufruf von addCar() dem
		// Schnappschuss entspricht, der unter db_one_car_added.xml im Projekt
		// abgelegt ist.
	}

	@Test
	public void testAddIllegalCar() throws Exception {
		// TODO Aufgabe 3b: Dieser Test schlägt fehl. Dabei erreicht er
		// eigentlich sein Ziel: Er soll testen, ob das fehlerhafte Hinzufügen
		// eines Autos in die Datenbank abgelehnt wird. Sorgen Sie dafür, dass
		// dieser Test durchläuft, wenn das Hinzufügen abgelehnt wird, und sonst
		// scheitert.
		dbWrite.addCar("", "Audi");
	}

	@Test
	public void testBookCar() {
		Datum from = new Datum(2017, 04, 16);
		Datum to = new Datum(2017, 04, 17);
		Set<String> car_ids = dbRead.findAvailableCar(from, to);
		assertTrue(car_ids.size() > 0);
		String car_id = car_ids.iterator().next();
		assertTrue(dbRead.findAvailableCar(from, to).contains(car_id));
		dbWrite.upsertBookingForCar(car_id, "00001002", from, to, DatabaseReadInterface.STATE_OPEN);
		assertFalse(dbRead.findAvailableCar(from, to).contains(car_id));
	}

	@Test
	public void testReturnCar() {
		Datum from = new Datum(2017, 04, 16);
		Datum to = new Datum(2017, 04, 26);
		assertFalse(dbRead.findAvailableCar(from, to).contains("M-LI 200"));
		dbWrite.upsertBookingForCar("M-LI 200", "00001001", from, to, DatabaseReadInterface.STATE_IN_RETURN);

		// Prüfen ob die Rückgabe erfolgreich war
		Set<BookingDTO> bookings = dbRead.getBookingsForCarAsDTOs("M-LI 200");
		assertEquals(1, bookings.size());
		BookingDTO booking = bookings.iterator().next();
		assertEquals(from, booking.getFrom());
		assertEquals(to, booking.getTo());
		// Hier muss jetzt das Ergebnis true sein
		assertTrue(booking.getState() == DatabaseReadInterface.STATE_IN_RETURN);
	}

	@Test
	public void testCloseBooking() {
		Datum from = new Datum(2017, 04, 16);
		Datum to = new Datum(2017, 04, 26);
		assertFalse(dbRead.findAvailableCar(from, to).contains("M-LI 200"));
		dbWrite.upsertBookingForCar("M-LI 200", "00001001", from, to, DatabaseReadInterface.STATE_CLOSED);

		// Prüfen ob die Rückgabe erfolgreich war
		Set<BookingDTO> bookings = dbRead.getBookingsForCarAsDTOs("M-LI 200");
		assertEquals(1, bookings.size());
		BookingDTO booking = bookings.iterator().next();
		assertEquals(from, booking.getFrom());
		assertEquals(to, booking.getTo());
		// Hier muss jetzt das Ergebnis false sein
		assertTrue(booking.getState() == DatabaseReadInterface.STATE_CLOSED);
	}
}
