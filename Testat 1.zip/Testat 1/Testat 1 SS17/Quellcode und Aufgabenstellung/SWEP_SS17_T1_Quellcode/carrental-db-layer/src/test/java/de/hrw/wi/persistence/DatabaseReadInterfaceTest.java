/**
 * 
 */
package de.hrw.wi.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import de.hrw.wi.persistence.dto.BookingDTO;
import de.hrw.wi.types.Datum;

/**
 * @author andriesc
 *
 */
public class DatabaseReadInterfaceTest {

	DatabaseReadInterface db;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		db = new RealDatabase();
	}

	@Test
	public void testGetAllCars() {
		Set<String> cars = db.getAllCars();
		assertNotNull(cars);
		assertEquals(5, cars.size());
		assertTrue(cars.contains("M-LI 200"));
		assertTrue(cars.contains("RV-HS 1000"));
		assertTrue(cars.contains("KA-PA 656"));
		assertTrue(cars.contains("KA-GB 652"));
		assertTrue(cars.contains("FN-TT 999"));
	}

	@Test
	public void testGetCarBrand() {
		String brand = db.getCarBrand("KA-GB 652");
		assertEquals("VW", brand);
		brand = db.getCarBrand("FN-TT 999");
		assertEquals("Audi", brand);
	}

	@Test
	public void testGetBookingsForCar() {
		Datum from = new Datum(2017, 4, 18);
		Datum to = new Datum(2017, 5, 2);
		Set<BookingDTO> bookings = db.getBookingsForCarAsDTOs("FN-TT 999");
		assertEquals(1, bookings.size());
		BookingDTO booking = bookings.iterator().next();
		assertEquals("FN-TT 999", booking.getCarId());
		assertEquals(from, booking.getFrom());
		assertEquals(to, booking.getTo());
		assertTrue(booking.getState() == DatabaseReadInterface.STATE_OPEN);
	}

	@Test
	public void testIsCarAvailable() {
		Datum from = new Datum(2017, 1, 1);
		Datum to = new Datum(2017, 1, 5);
		Boolean avail = db.isCarAvailable("KA-PA 656", from, to);
		assertTrue(avail);
		from = new Datum(2017, 04, 4);
		to = new Datum(2017, 4, 5);
		avail = db.isCarAvailable("KA-PA 656", from, to);
		assertFalse(avail);
	}

	@Test
	public void testFindAvailableCar() {
		Datum from = new Datum(2017, 4, 7);
		Datum to = new Datum(2017, 4, 15);
		Set<String> availCars = db.findAvailableCar(from, to);
		assertEquals(4, availCars.size());
		assertTrue(availCars.contains("M-LI 200"));
		assertTrue(availCars.contains("KA-GB 652"));
		assertTrue(availCars.contains("KA-PA 656"));
		assertTrue(availCars.contains("FN-TT 999"));
	}

	@Test
	public void testGetAllCustomers() {
		Set<String> customers = db.getAllCustomers();
		assertEquals(4, customers.size());
		assertTrue(customers.contains("00001000"));
		assertTrue(customers.contains("00001001"));
		assertTrue(customers.contains("00001002"));
		assertTrue(customers.contains("00001003"));
	}

	@Test
	public void testGetFirstName() {
		assertEquals("Grace", db.getFirstName("00001000"));
		assertEquals("Emmy", db.getFirstName("00001001"));
		assertEquals("Ada", db.getFirstName("00001002"));
	}

	@Test
	public void testGetLastName() {
		assertEquals("Hopper", db.getLastName("00001000"));
		assertEquals("Noether", db.getLastName("00001001"));
		assertEquals("Lovelace", db.getLastName("00001002"));
	}
}
