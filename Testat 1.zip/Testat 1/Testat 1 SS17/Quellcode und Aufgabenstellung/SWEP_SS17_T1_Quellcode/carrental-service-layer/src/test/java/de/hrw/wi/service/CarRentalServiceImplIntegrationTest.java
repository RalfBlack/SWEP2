/**
 * 
 */
package de.hrw.wi.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Set;

import org.dbunit.IDatabaseTester;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Before;
import org.junit.Test;

import de.hrw.wi.business.Car;
import de.hrw.wi.business.Customer;
import de.hrw.wi.business.bookings.Booking;
import de.hrw.wi.persistence.RealDatabase;
import de.hrw.wi.types.Datum;

/**
 * @author andriesc
 *
 */
public class CarRentalServiceImplIntegrationTest {
	private final String dbURL = "jdbc:hsqldb:file:../carrental-db-layer/database/carrental_db";
	private final String user = "sa";
	private final String password = "";

	private CarRentalServiceInterface carRentalService;
	private IDatabaseTester databaseTester;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		RealDatabase db = new RealDatabase();
		// TODO Aufgabe 5: CarRentalServiceImpl verwendet Dependency Injection.
		// Diese Klasse (CarRentalServiceImplIntegrationTest) testet
		// CarRentalServiceImpl. Derzeit ist carRentalService einfach auf null
		// gesetzt, damit laufen die Tests nicht durch. Initialisieren Sie
		// carRentalService hier für die Tests.
		carRentalService = null;

		databaseTester = new JdbcDatabaseTester("org.hsqldb.jdbcDriver", dbURL, user, password);
		databaseTester
				.setDataSet(new FlatXmlDataSetBuilder().build(new File("../carrental-db-layer/db_full_export.xml")));
		databaseTester.onSetup();
	}

	@Test
	public void testAddCar() {
		Car car = new Car("Audi", "RV-CA 2015");
		boolean status = carRentalService.addCar(car);
		assertTrue(status);
	}

	@Test
	public void testGetAllCars() {
		Set<Car> cars = carRentalService.getAllCars();
		assertEquals(5, cars.size());
	}

	@Test
	public void testBookCar() {
		Customer customer = new Customer("00001002", "Ada", "Lovelace");
		Datum from = new Datum(2015, 11, 16);
		Datum to = new Datum(2015, 11, 17);
		Set<Car> cars = carRentalService.findAvailableCar(from, to);
		assertTrue(cars.size() > 0);
		Car rentalCar = cars.iterator().next();
		Booking booking = carRentalService.bookCar(rentalCar, customer, from, to);
		assertEquals(rentalCar.getBrand(), booking.getCar().getBrand());
		assertEquals(rentalCar.getId(), booking.getCar().getId());
		assertEquals(from, booking.getFrom());
		assertEquals(to, booking.getTo());
	}

	@Test
	public void testIsCarAvailable() {
		Car car = new Car("Honda", "KA-PA 656");
		Datum from = new Datum(2017, 1, 1);
		Datum to = new Datum(2017, 1, 5);
		Boolean avail = carRentalService.isCarAvailable(car, from, to);
		assertTrue(avail);
		from = new Datum(2017, 04, 4);
		to = new Datum(2017, 04, 5);
		avail = carRentalService.isCarAvailable(car, from, to);
		assertFalse(avail);
	}

	@Test
	public void testFindAvailableCar() {
		Datum from = new Datum(2015, 11, 04);
		Datum to = new Datum(2015, 11, 05);
		Set<Car> cars = carRentalService.findAvailableCar(from, to);
		assertTrue(carRentalService.isCarAvailable(cars.iterator().next(), from, to));
	}

	@Test
	public void testGetAllCustomers() {
		Set<Customer> customers = carRentalService.getAllCustomers();
		assertEquals(4, customers.size());
		boolean hopperFound = false;
		boolean noetherFound = false;
		boolean lovelaceFound = false;
		boolean turingFound = false;
		for (Customer customer : customers) {
			if (customer.getFirstName().equals("Emmy") && customer.getLastName().equals("Noether"))
				noetherFound = true;
			if (customer.getFirstName().equals("Grace") && customer.getLastName().equals("Hopper"))
				hopperFound = true;
			if (customer.getFirstName().equals("Ada") && customer.getLastName().equals("Lovelace"))
				lovelaceFound = true;
			if (customer.getFirstName().equals("Alan") && customer.getLastName().equals("Turing"))
				turingFound = true;

		}
		assertTrue(noetherFound);
		assertTrue(hopperFound);
		assertTrue(lovelaceFound);
		assertTrue(turingFound);
	}

	@Test
	public void testReturnCar() {
		Car car = new Car("Honda", "KA-PA 656");
		Datum returnDate = new Datum(2017, 04, 1);
		Booking booking = carRentalService.returnCar(car, returnDate);
		assertNull(booking);
		returnDate = new Datum(2017, 04, 26);
		car = new Car("BMW", "M-LI 200");
		booking = carRentalService.returnCar(car, returnDate);
		assertTrue(booking.isCarInReturn());
	}

	@Test
	public void testCloseBookingForCar() {
		Car car = new Car("Honda", "KA-PA 656");
		Datum returnDate = new Datum(2017, 04, 1);
		Booking booking = carRentalService.closeBookingForCar(car, returnDate);
		assertNull(booking);
		returnDate = new Datum(2017, 04, 26);
		car = new Car("BMW", "M-LI 200");
		carRentalService.returnCar(car, returnDate);
		booking = carRentalService.closeBookingForCar(car, returnDate);
		assertTrue(booking.isClosed());
	}
}
