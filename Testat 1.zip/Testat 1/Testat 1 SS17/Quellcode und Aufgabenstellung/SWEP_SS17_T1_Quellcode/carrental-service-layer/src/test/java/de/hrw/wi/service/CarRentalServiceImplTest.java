/**
 * 
 */
package de.hrw.wi.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import de.hrw.wi.business.Car;
import de.hrw.wi.persistence.DatabaseReadInterface;
import de.hrw.wi.persistence.DatabaseWriteInterface;

/**
 * Teste CarRentalServiceImpl mit Mocking
 * 
 * @author andriesc
 *
 */
public class CarRentalServiceImplTest {

	private CarRentalServiceInterface carRentalService;
	private DatabaseReadInterface dbReadMock;
	private DatabaseWriteInterface dbWriteMock;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		// Erzeuge Mock-Objekt -- Leseinterface
		dbReadMock = Mockito.mock(DatabaseReadInterface.class);

		Set<String> cars = new HashSet<String>(Arrays.asList("RV-HS 111", "UL-M 123"));

		// TODO Aufgabe 7: Das Mock-Objekt dbReadMock ist nicht fertig
		// initialisiert. Führen Sie die Schnittstellenbeschreibung für das
		// Mock-Objekt dbReadMock mit Mockito so vor , dass die Tests
		// testGetAllCars() und testGetCarBrand() durchlaufen.

		// dbWriteMock ist und bleibt uninitialisiert
		carRentalService = new CarRentalServiceImpl(dbReadMock, dbWriteMock);

	}

	@Test
	public void testGetAllCars() {
		Set<Car> cars = carRentalService.getAllCars();
		assertEquals(2, cars.size());
		// Die Autos alle überprüfen
		for (Car car : cars) {
			// Nach Kennzeichen auf Marke prüfen
			switch (car.getId()) {
			case "RV-HS 111":
				assertEquals("Peugeot", car.getBrand());
				break;
			case "UL-M 123":
				assertEquals("Porsche", car.getBrand());
				break;
			default:
				fail();
			}
		}
	}

}
