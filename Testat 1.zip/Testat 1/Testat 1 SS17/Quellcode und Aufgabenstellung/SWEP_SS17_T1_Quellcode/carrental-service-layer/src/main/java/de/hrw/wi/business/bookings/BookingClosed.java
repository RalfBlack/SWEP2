/**
 * 
 */
package de.hrw.wi.business.bookings;

/**
 * @author andriesc
 *
 */
public class BookingClosed implements BookingState {
	private Booking booking;

	public BookingClosed(Booking booking) {
		this.booking = booking;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hrw.wi.business.BookingState#returnCar()
	 */
	@Override
	public void returnCar() {
		throw new IllegalStateException("Booking has already been closed.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hrw.wi.business.BookingState#closeBooking()
	 */
	@Override
	public void closeBooking() {
		throw new IllegalStateException("Booking has already been closed.");
	}

	@Override
	public boolean isOpen() {
		return false;
	}

	@Override
	public boolean isCarInReturn() {
		return false;
	}

	@Override
	public boolean isClosed() {
		return true;
	}

}
