package de.hrw.wi.service;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import de.hrw.wi.business.Car;
import de.hrw.wi.business.Customer;
import de.hrw.wi.business.bookings.Booking;
import de.hrw.wi.persistence.DatabaseReadInterface;
import de.hrw.wi.persistence.DatabaseWriteInterface;
import de.hrw.wi.persistence.PersistenceException;
import de.hrw.wi.persistence.dto.BookingDTO;
import de.hrw.wi.types.Datum;

public class CarRentalServiceImpl implements CarRentalServiceInterface {

	DatabaseReadInterface dbRead;
	DatabaseWriteInterface dbWrite;

	public CarRentalServiceImpl(DatabaseReadInterface dbRead, DatabaseWriteInterface dbWrite) {
		this.dbRead = dbRead;
		this.dbWrite = dbWrite;
	}

	@Override
	public boolean addCar(Car car) {
		try {
			dbWrite.addCar(car.getId(), car.getBrand().toString());
		} catch (PersistenceException e) {
			return false;
		}
		return true;
	}

	@Override
	public Set<Car> getAllCars() {
		Set<Car> cars = new HashSet<Car>();
		for (String id : dbRead.getAllCars()) {
			cars.add(new Car(dbRead.getCarBrand(id), id));
		}
		return cars;
	}

	@Override
	public boolean isCarAvailable(Car car, Datum from, Datum to) {
		return dbRead.isCarAvailable(car.getId(), from, to);
	}

	@Override
	public Set<Car> findAvailableCar(Datum from, Datum to) {
		Set<Car> cars = new HashSet<Car>();
		for (String id : dbRead.findAvailableCar(from, to)) {
			cars.add(new Car(dbRead.getCarBrand(id), id));
		}
		return cars;
	}

	@Override
	public Set<Customer> getAllCustomers() {
		Set<Customer> customers = new HashSet<Customer>();
		for (String id : dbRead.getAllCustomers()) {
			customers.add(new Customer(id, dbRead.getFirstName(id), dbRead.getLastName(id)));
		}
		return customers;
	}

	@Override
	public Booking bookCar(Car car, Customer cust, Datum from, Datum to) {
		if (isCarAvailable(car, from, to)) {
			// Autobuchung anlegen
			dbWrite.upsertBookingForCar(car.getId(), cust.getId(), from, to, DatabaseReadInterface.STATE_OPEN);
			return new Booking(car, cust, from, to);
		} else
			return null;
	}

	@Override
	public Booking returnCar(Car car, Datum returnDate) {
		Set<Booking> bookings = getOpenBookingsForCar(car);
		Iterator<Booking> iter = bookings.iterator();
		Booking bookingResult = null;
		while (iter.hasNext() && (bookingResult == null)) {
			Booking booking = iter.next();
			if (booking.isOpen() && booking.getFrom().isBefore(returnDate)) {
				// Zugehörige Buchung gefunden, Auto zurückgeben
				dbWrite.upsertBookingForCar(car.getId(), booking.getCustomer().getId(), booking.getFrom(),
						booking.getTo(), DatabaseReadInterface.STATE_IN_RETURN);
				booking.returnCar();
				bookingResult = booking;
			}
		}
		return bookingResult;
	}

	@Override
	public Set<Booking> getOpenBookingsForCar(Car car) {
		Set<Booking> result = new HashSet<Booking>();
		Set<BookingDTO> bookingDtos = dbRead.getBookingsForCarAsDTOs(car.getId());
		for (BookingDTO dto : bookingDtos) {
			if ((dto.getState() == DatabaseReadInterface.STATE_OPEN)
					|| (dto.getState() == DatabaseReadInterface.STATE_IN_RETURN)) {
				Customer customer = new Customer(dto.getCustomerId(), dbRead.getFirstName(dto.getCustomerId()),
						dbRead.getLastName(dto.getCustomerId()));
				Booking booking = new Booking(car, customer, dto.getFrom(), dto.getTo(), dto.getState());
				result.add(booking);
			}
		}
		return result;
	}

	@Override
	public Booking closeBookingForCar(Car car, Datum returnDate) {
		Set<Booking> bookings = getOpenBookingsForCar(car);
		Iterator<Booking> iter = bookings.iterator();
		Booking bookingResult = null;
		while (iter.hasNext() && (bookingResult == null)) {
			Booking booking = iter.next();
			if (booking.isCarInReturn() && booking.getFrom().isBefore(returnDate)) {
				// Zugehörige Buchung gefunden, Auto zurückgeben
				dbWrite.upsertBookingForCar(car.getId(), booking.getCustomer().getId(), booking.getFrom(),
						booking.getTo(), DatabaseReadInterface.STATE_CLOSED);
				booking.closeBooking();
				bookingResult = booking;
			}
		}
		return bookingResult;
	}

}
