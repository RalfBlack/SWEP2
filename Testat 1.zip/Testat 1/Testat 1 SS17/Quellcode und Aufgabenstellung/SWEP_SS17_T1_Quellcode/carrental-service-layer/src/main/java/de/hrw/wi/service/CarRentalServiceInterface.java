/**
 * 
 */
package de.hrw.wi.service;

import java.util.Set;

import de.hrw.wi.business.Car;
import de.hrw.wi.business.Customer;
import de.hrw.wi.business.bookings.Booking;
import de.hrw.wi.types.Datum;

/**
 * @author andriesc
 *
 */
public interface CarRentalServiceInterface {

	/**
	 * Fügt ein Auto als buchbaren Leihwagen hinzu.
	 * 
	 * @author andriesc
	 * @param Car
	 *            Das zu hinzuzufügende Auto
	 * @return true, wenn das Auto hinzugefügt werden konnte
	 */
	boolean addCar(Car car);

	/**
	 * 
	 * @return Alle Autos im Verleih, die nicht deaktiviert sind
	 */
	Set<Car> getAllCars();

	/**
	 * 
	 * 
	 * @param car
	 * @return true, wenn das Auto im Zeitraum from-to noch nicht ausgeliehen
	 *         ist
	 */
	boolean isCarAvailable(Car car, Datum from, Datum to);

	/**
	 * 
	 * @param from
	 * @param to
	 * @return
	 */
	Set<Car> findAvailableCar(Datum from, Datum to);

	/**
	 * 
	 * @return
	 */
	Set<Customer> getAllCustomers();

	/**
	 * Zum Verleihen eines Autos. Das Auto muss verfügbar sein, darf also noch
	 * nicht im selben Zeitraum ausgeliehen sein! Die erzeugte Buchung bleibt
	 * offen, bis das Auto zurückgenommen wurde.
	 * 
	 * Ein Auto kann an dem Tag, an dem es zurückgebracht wurde, nicht mehr
	 * ausgeliehen werden. Deshalb ist es egal, zu welcher Uhrzeit es
	 * zurückgebracht oder ausgeliehen wird.
	 * 
	 * @param car
	 * @param cust
	 * @param from
	 *            Datum, ab dem das Auto ausgeliehen wird (Uhrzeit ist egal)
	 * @param to
	 *            Datum, zu dem das Auto zurückgebracht wird (Uhrzeit ist egal)
	 * @return Die erzeugte Buchung oder null, wenn die Buchung fehlschlug
	 */
	Booking bookCar(Car car, Customer cust, Datum from, Datum to);

	/**
	 * Rücknahme eines Autos. Auto kann nur zurückgenommen werden, wenn es auch
	 * ausgeliehen war und diese Buchung noch nicht abgeschlossen ist. Die
	 * passende Buchung wird über das Rückgabedatum gesucht, was im
	 * Buchungszeitraum liegen muss.
	 * 
	 * @param car
	 *            Das Auto, das zurückgegeben wird
	 * @param returnDate
	 *            Datum, an dem das Auto zurückgegeben wird. Das Rückgabedatum
	 *            muss größer oder gleich dem Startdatum der Reservierung sein.
	 * @return Die Buchung, für die das Auto zurückgenommen wurde oder
	 *         <code>null</code>, wenn keine passende Buchung gefunden wurde
	 */
	Booking returnCar(Car car, Datum returnDate);

	/**
	 * Abschluss der Buchung eines Autos. Das kann nur erfolgen, wenn das Auto
	 * vorher schon zurückgenommen wurde und die Buchung noch nicht
	 * abgeschlossen ist. Die passende Buchung wird über das Rückgabedatum
	 * gesucht, was im Buchungszeitraum liegen muss.
	 * 
	 * @param car
	 * @param returnDate
	 * @return Die Buchung, die abgeschlossen wurde oder <code>null</code>, wenn
	 *         keine passende gefunden wurde
	 */
	Booking closeBookingForCar(Car car, Datum returnDate);

	/**
	 * 
	 * @param car
	 *            Das Auto, zu dem die Buchungen zurückgegeben werden sollen
	 * @return alle Buchungen für das Auto, die noch nicht geschlossen sind
	 *         (also "offen" oder "Auto in Rücknahme")
	 */
	Set<Booking> getOpenBookingsForCar(Car car);
}
