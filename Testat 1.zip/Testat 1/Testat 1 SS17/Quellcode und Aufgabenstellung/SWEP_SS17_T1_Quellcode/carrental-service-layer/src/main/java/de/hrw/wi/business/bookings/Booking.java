/**
 * 
 */
package de.hrw.wi.business.bookings;

import de.hrw.wi.business.Car;
import de.hrw.wi.business.Customer;
import de.hrw.wi.persistence.DatabaseReadInterface;
import de.hrw.wi.types.Datum;

/**
 * Buchung eines Autos als Ausleihe. Das Auto zu einer Buchung kann nicht
 * geändert werden. Eine Buchung bleibt nach Anlage offen, bis das Auto
 * zurückgegeben wird. Eine geschlossene Buchung kann nicht neu geöffnet werden.
 * 
 * @author andriesc
 *
 */
public class Booking {

	private BookingState state;
	private Car car;
	private Customer customer;
	private Datum from;
	private Datum to;

	public Booking(Car car, Customer customer, Datum from, Datum to) {
		this.car = car;
		this.customer = customer;
		this.from = from;
		this.to = to;
		state = new BookingOpen(this);
	}

	public Booking(Car car, Customer customer, Datum from, Datum to, int state) {
		this.car = car;
		this.customer = customer;
		this.from = from;
		this.to = to;
		switch (state) {
		case DatabaseReadInterface.STATE_OPEN:
			this.state = new BookingOpen(this);
			break;
		case DatabaseReadInterface.STATE_IN_RETURN:
			this.state = new CarInReturn(this);
			break;
		case DatabaseReadInterface.STATE_CLOSED:
			this.state = new BookingClosed(this);
			break;
		default:
			throw new IllegalStateException("Illegal state for booking.");
		}
	}

	public void returnCar() {
		state.returnCar();
	};

	public void closeBooking() {
		state.closeBooking();
	}

	public boolean isOpen() {
		return state.isOpen();
	}

	public boolean isCarInReturn() {
		return state.isCarInReturn();
	}

	public boolean isClosed() {
		return state.isClosed();
	}

	protected void setState(BookingState state) {
		this.state = state;
	}

	public Car getCar() {
		return car;
	}

	public Datum getFrom() {
		return from;
	}

	public Datum getTo() {
		return to;
	}

	public void setFrom(Datum from) {
		this.from = from;
	}

	public void setTo(Datum to) {
		this.to = to;
	}

	public Customer getCustomer() {
		return customer;
	}
}
