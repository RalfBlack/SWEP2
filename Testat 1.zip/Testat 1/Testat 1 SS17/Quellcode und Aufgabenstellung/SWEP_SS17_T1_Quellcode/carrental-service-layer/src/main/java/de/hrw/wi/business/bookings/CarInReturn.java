/**
 * 
 */
package de.hrw.wi.business.bookings;

/**
 * @author andriesc
 *
 */
public class CarInReturn implements BookingState {
	private Booking booking;

	public CarInReturn(Booking booking) {
		this.booking = booking;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hrw.wi.business.BookingState#returnCar()
	 */
	@Override
	public void returnCar() {
		// TODO Aufgabe 6: Implementieren Sie returnCar() für den Zustand CarInReturn.
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hrw.wi.business.BookingState#closeBooking()
	 */
	@Override
	public void closeBooking() {
		// TODO Aufgabe 6: Implementieren Sie closeBooking() für den Zustand CarInReturn.
	}

	@Override
	public boolean isOpen() {
		return false;
	}

	@Override
	public boolean isCarInReturn() {
		return true;
	}

	@Override
	public boolean isClosed() {
		return false;
	}

}
