/**
 * 
 */
package de.hrw.wi.business.bookings;

/**
 * @author andriesc
 *
 */
public class BookingOpen implements BookingState {
	private Booking booking;
	
	public BookingOpen(Booking booking) {
		this.booking = booking;
	}

	/* (non-Javadoc)
	 * @see de.hrw.wi.business.BookingState#returnCar()
	 */
	@Override
	public void returnCar() {
		booking.setState(new CarInReturn(booking));
	}

	/* (non-Javadoc)
	 * @see de.hrw.wi.business.BookingState#closeBooking()
	 */
	@Override
	public void closeBooking() {
		throw new IllegalStateException("Booking cannot be closed, car has not been returned yet.");
	}

	@Override
	public boolean isOpen() {
		return true;
	}

	@Override
	public boolean isCarInReturn() {
		return false;
	}

	@Override
	public boolean isClosed() {
		return false;
	}

}
