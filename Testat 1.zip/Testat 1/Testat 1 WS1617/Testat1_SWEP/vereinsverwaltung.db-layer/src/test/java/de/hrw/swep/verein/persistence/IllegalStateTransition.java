package de.hrw.swep.verein.persistence;

public class IllegalStateTransition implements DataStoreTest.java {

}
